/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.riddlegame;

/**
 *
 * @author RC_Student_lab
 */import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;

public class RiddleGame {
    
    // Use ArrayLists for dynamic management of riddles
    private static final ArrayList<String> riddles = new ArrayList<>();
    private static final ArrayList<String[]> options = new ArrayList<>();
    private static final ArrayList<String> answers = new ArrayList<>();

    // Static block to initialize the 15 riddles
    static {
        // Riddle 1
        riddles.add("I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I?");
        options.add(new String[]{"An echo", "A secret", "A ghost"});
        answers.add("An echo");

        // Riddle 2
        riddles.add("What has an eye, but cannot see?");
        options.add(new String[]{"A needle", "A key", "A lock"});
        answers.add("A needle");

        // Riddle 3
        riddles.add("What is full of holes but still holds water?");
        options.add(new String[]{"A sponge", "A sieve", "A net"});
        answers.add("A sponge");

        // Riddle 4
        riddles.add("What question can you never answer yes to?");
        options.add(new String[]{"Are you asleep yet?", "Is it raining?", "Are you hungry?"});
        answers.add("Are you asleep yet?");
        
        // Riddle 5
        riddles.add("What belongs to you, but other people use it more than you do?");
        options.add(new String[]{"Your name", "Your phone", "Your car"});
        answers.add("Your name");
        
        // Riddle 6
        riddles.add("What has a neck but no head?");
        options.add(new String[]{"A bottle", "A shirt", "A giraffe"});
        answers.add("A bottle");
        
        // Riddle 7
        riddles.add("What has a thumb and four fingers, but is not alive?");
        options.add(new String[]{"A glove", "A hand", "A sock"});
        answers.add("A glove");

        // Riddle 8
        riddles.add("What is always in front of you but can't be seen?");
        options.add(new String[]{"The future", "The past", "Your shadow"});
        answers.add("The future");

        // Riddle 9
        riddles.add("What goes up but never comes down?");
        options.add(new String[]{"Your age", "A rocket", "A balloon"});
        answers.add("Your age");

        // Riddle 10
        riddles.add("What has cities, but no houses; forests, but no trees; and water, but no fish?");
        options.add(new String[]{"A map", "A globe", "A book"});
        answers.add("A map");
        
        // Riddle 11
        riddles.add("What can be broken without being touched?");
        options.add(new String[]{"A promise", "A window", "A heart"});
        answers.add("A promise");
        
        // Riddle 12
        riddles.add("I am an odd number. Take away a letter and I become even. What number am I?");
        options.add(new String[]{"Seven", "Nine", "Five"});
        answers.add("Seven");
        
        // Riddle 13
        riddles.add("What has to be broken before you can use it?");
        options.add(new String[]{"An egg", "A stick", "A plate"});
        answers.add("An egg");
        
        // Riddle 14
        riddles.add("What is so fragile that saying its name breaks it?");
        options.add(new String[]{"Silence", "A mirror", "A light bulb"});
        answers.add("Silence");
        
        // Riddle 15
        riddles.add("What is full of keys but can't open a single lock?");
        options.add(new String[]{"A keyboard", "A piano", "A keychain"});
        answers.add("A keyboard");
    }

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        try (scanner) {
            boolean exit = false;
            while (!exit) {
                System.out.println("\n--- Riddle Game Menu ---");
                System.out.println("1. Play Game");
                System.out.println("2. Add a Riddle");
                System.out.println("3. Delete a Riddle");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");
                
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                
                switch (choice) {
                    case 1 -> playGame();
                    case 2 -> addRiddle();
                    case 3 -> deleteRiddle();
                    case 4 -> {
                        exit = true;
                        System.out.println("Thank you for playing!");
                    }
                    default -> System.out.println("Invalid choice. Please try again.");
                }
            }
        }
    }
    
    // Method to handle the game play
    private static void playGame() {
        if (riddles.isEmpty()) {
            System.out.println("There are no riddles to play. Please add some first.");
            return;
        }

        int score = 0;
        System.out.println("\n--- Starting Game ---");
        for (int i = 0; i < riddles.size(); i++) {
            System.out.println("\n" + (i + 1) + ". " + riddles.get(i));
            System.out.println("Options:");
            String[] currentOptions = options.get(i);
            for (int j = 0; j < currentOptions.length; j++) {
                System.out.println("  " + (j + 1) + ". " + currentOptions[j]);
            }

            System.out.print("Enter your choice (1-" + currentOptions.length + "): ");
            int userChoice = scanner.nextInt();
            
            if (userChoice >= 1 && userChoice <= currentOptions.length) {
                String chosenAnswer = currentOptions[userChoice - 1];
                if (chosenAnswer.equals(answers.get(i))) {
                    System.out.println("Correct! 🎉");
                    score++;
                } else {
                    System.out.println("Incorrect. The correct answer was: " + answers.get(i));
                }
            } else {
                System.out.println("Invalid choice. Skipping to the next riddle.");
            }
            scanner.nextLine(); // Consume newline
        }

        System.out.println("\n--- Game Over ---");
        System.out.println("Your final score is: " + score + "/" + riddles.size());
    }

    // Method to add a new riddle
    private static void addRiddle() {
        System.out.println("\n--- Add a New Riddle ---");
        System.out.print("Enter the riddle question: ");
        String riddle = scanner.nextLine();
        
        System.out.println("Enter the three options (press Enter after each):");
        String[] newOptions = new String[3];
        for (int i = 0; i < 3; i++) {
            System.out.print("Option " + (i + 1) + ": ");
            newOptions[i] = scanner.nextLine();
        }

        System.out.print("Enter the correct answer from the options above: ");
        String answer = scanner.nextLine();

        // Validate that the correct answer is one of the options
        if (Arrays.asList(newOptions).contains(answer)) {
            riddles.add(riddle);
            options.add(newOptions);
            answers.add(answer);
            System.out.println("Riddle added successfully!");
        } else {
            System.out.println("Error: The answer must be one of the provided options. Riddle not added.");
        }
    }

    // Method to delete a riddle
    private static void deleteRiddle() {
        if (riddles.isEmpty()) {
            System.out.println("There are no riddles to delete.");
            return;
        }

        System.out.println("\n--- Delete a Riddle ---");
        System.out.println("Current Riddles:");
        for (int i = 0; i < riddles.size(); i++) {
            System.out.println((i + 1) + ". " + riddles.get(i));
        }

        System.out.print("Enter the number of the riddle to delete (or 0 to cancel): ");
        int choice = scanner.nextInt();
        
        if (choice > 0 && choice <= riddles.size()) {
            int index = choice - 1;
            riddles.remove(index);
            options.remove(index);
            answers.remove(index);
            System.out.println("Riddle " + choice + " deleted successfully!");
        } else if (choice == 0) {
            System.out.println("Deletion canceled.");
        } else {
            System.out.println("Invalid number. No riddle was deleted.");
        }
        scanner.nextLine(); // Consume newline
    }
}
